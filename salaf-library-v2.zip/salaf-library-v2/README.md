# 📚 Salaf Library — مكتبة السلف

Полноценная цифровая исламская библиотека, объединяющая все лучшие наработки из предыдущих версий проекта.

## 🚀 Технологический стек

- **React 19 + TypeScript**
- **Vite 7 + Tailwind CSS 4**
- **Zustand** (persist — localStorage)
- **React Router 7** (HashRouter для GitHub Pages)
- **react-i18next** (мультиязычность: 🇷🇺 🇸🇦 🇬🇧)
- **react-hot-toast** (уведомления)
- **vite-plugin-singlefile** (один HTML на выходе)
- **Lucide React** (иконки)

## 📦 Установка и запуск

```bash
npm install
npm run dev     # Локальный сервер
npm run build   # Production build
npm run preview # Превью сборки
```

## 🌍 Деплой на GitHub Pages

1. Загрузите проект в GitHub репозиторий
2. Включите GitHub Pages (Settings → Pages → GitHub Actions)
3. Workflow `.github/workflows/deploy.yml` запустится автоматически

## 📂 Структура проекта

```
src/
  ├── components/       # Sidebar, Header, AudioPlayer, BookCard, etc.
  ├── pages/            # Home, Books, BookDetail, Biographies, Audio, Fawaid,
  │                     #   Search, Favorites, History, Categories, Admin,
  │                     #   Dashboard, Goals, ReadingPlans
  ├── pages/admin/      # AdminImportPage, AdminStatsPage, AdminSettingsPage
  ├── data/             # books, biographies, audio, fawaid, categories, goals
  ├── store/            # Zustand store (persist)
  ├── i18n/             # Переводы (ru, ar, en)
  └── utils/            # cn (clsx + tailwind-merge)
public/
  ├── *.webp            # Обложки книг (из web-main)
  └── scripts/          # Python скрипты (import_books.py, build_indexes.py, etc.)
```

## ✅ Реализованный функционал

| Функция | Статус |
|---------|--------|
| 📚 Книги (20+) | ✅ |
| 👤 Биографии (пророки, сподвижники, табиины, учёные) | ✅ |
| 🎧 Аудиоуроки (12+) | ✅ |
| 💡 Фаваиды (16+) | ✅ |
| 📂 Категории (12) | ✅ |
| 🔍 Поиск | ✅ |
| ❤️ Избранное | ✅ |
| 📜 История | ✅ |
| 📊 Dashboard | ✅ |
| 🎯 Goals | ✅ |
| 📅 Reading Plans | ✅ |
| 🎵 Audio Player | ✅ |
| ⚙️ Admin Panel | ✅ |
| 📥 Smart Import (демо) | ✅ |
| 🌍 Мультиязычность (RU/AR/EN) | ✅ |
| 📱 Адаптивный дизайн | ✅ |
| 🌙 Тёмная тема | ✅ |
| 🔒 Offline-first (PWA-ready) | ✅ |

## 📝 Примечание

Это финальная объединённая версия, содержащая весь функционал из всех предыдущих архивов:
- `automate-book-management-system`
- `awaiting-files-and-instructions`
- `implement-reading-plan-features`
- `salaf-library-premium-redesign`
- `salaf-library-product-enhancement`
- `salaf-library-production-polish`
- `salaf-library-production-readiness`
- `web-main`

---

**Разработчик:** [aminmod-bit](https://github.com/aminmod-bit)
